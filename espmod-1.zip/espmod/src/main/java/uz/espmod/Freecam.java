package uz.espmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.Vec3d;

/**
 * Freecam: the camera detaches from the player and flies around freely.
 * The real player stays where it is (its input is replaced by an empty one).
 */
public final class Freecam {
    private Freecam() {}

    public static boolean enabled = false;
    public static Vec3d pos = Vec3d.ZERO;
    public static Vec3d prevPos = Vec3d.ZERO;
    public static float yaw;
    public static float pitch;

    private static Input savedInput;
    private static ClientPlayerEntity trackedPlayer;

    public static void toggle(MinecraftClient mc) {
        if (enabled) disable(mc);
        else enable(mc);
    }

    public static void enable(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || enabled) return;

        pos = player.getEyePos();
        prevPos = pos;
        yaw = player.getYaw();
        pitch = player.getPitch();

        trackedPlayer = player;
        savedInput = player.input;
        player.input = new Input();
        enabled = true;
    }

    public static void disable(MinecraftClient mc) {
        if (!enabled) return;
        enabled = false;

        // Only restore the input if it is still the same player object.
        if (mc.player != null && mc.player == trackedPlayer && savedInput != null) {
            mc.player.input = savedInput;
        }
        savedInput = null;
        trackedPlayer = null;
    }

    public static void tick(MinecraftClient mc) {
        if (!enabled) return;

        // World left / player respawned -> the old player object is gone.
        if (mc.player == null || mc.world == null || mc.player != trackedPlayer) {
            enabled = false;
            savedInput = null;
            trackedPlayer = null;
            return;
        }

        // Keep the real player frozen even if something swapped its input back.
        if (mc.player.input != null && mc.player.input.getClass() != Input.class) {
            savedInput = mc.player.input;
            mc.player.input = new Input();
        }

        // Don't fly around while a screen (menu, chat, inventory) is open.
        if (mc.currentScreen != null) {
            prevPos = pos;
            return;
        }

        GameOptions o = mc.options;
        double forward = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double side = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        double up = (o.jumpKey.isPressed() ? 1 : 0) - (o.sneakKey.isPressed() ? 1 : 0);

        Vec3d look = Vec3d.fromPolar(pitch, yaw);
        Vec3d left = Vec3d.fromPolar(0.0f, yaw - 90.0f);

        Vec3d move = look.multiply(forward).add(left.multiply(side)).add(0.0, up, 0.0);
        prevPos = pos;
        if (move.lengthSquared() > 1.0E-6) {
            double speed = Config.freecamSpeed * (o.sprintKey.isPressed() ? 2.5 : 1.0);
            pos = pos.add(move.normalize().multiply(speed));
        }
    }
}
