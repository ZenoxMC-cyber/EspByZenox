package uz.espmod.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.espmod.Freecam;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    /** After vanilla positions the camera, move it to the freecam position. */
    @Inject(method = "update", at = @At("TAIL"))
    private void espmod$freecam(BlockView area, Entity focusedEntity, boolean thirdPerson,
                                boolean inverseView, float tickDelta, CallbackInfo ci) {
        if (!Freecam.enabled) return;
        Vec3d p = Freecam.prevPos.lerp(Freecam.pos, tickDelta);
        this.setPos(p.x, p.y, p.z);
        this.setRotation(Freecam.yaw, Freecam.pitch);
    }

    /** Makes the game render your own player model while in freecam. */
    @Inject(method = "isThirdPerson", at = @At("HEAD"), cancellable = true)
    private void espmod$showPlayer(CallbackInfoReturnable<Boolean> cir) {
        if (Freecam.enabled) cir.setReturnValue(true);
    }
}
