package uz.espmod.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Lets us write the gamma value directly, bypassing the 0..1 slider validation. */
@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor<T> {
    @Mutable
    @Accessor("value")
    void espmod$setValue(T value);
}
