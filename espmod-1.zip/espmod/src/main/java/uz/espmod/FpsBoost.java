package uz.espmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** One-click low settings for more FPS. Applied once when the button is pressed. */
public final class FpsBoost {
    private FpsBoost() {}

    public static void apply(MinecraftClient mc) {
        GameOptions o = mc.options;
        if (o == null) return;

        o.getViewDistance().setValue(6);
        o.getSimulationDistance().setValue(5);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getEntityShadows().setValue(false);
        o.getAo().setValue(false);
        o.getBiomeBlendRadius().setValue(0);
        o.getEntityDistanceScaling().setValue(0.5);

        o.write();
        // Re-load chunks with the new distance.
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }
}
