package uz.espmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import uz.espmod.mixin.SimpleOptionAccessor;

/** Fullbright by forcing the gamma option far above the normal 0..1 range. */
public final class Fullbright {
    private Fullbright() {}

    private static final double BRIGHT = 16.0;
    private static Double saved = null;

    @SuppressWarnings("unchecked")
    private static void set(SimpleOption<Double> option, double value) {
        ((SimpleOptionAccessor<Double>) (Object) option).espmod$setValue(value);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        SimpleOption<Double> gamma = mc.options.getGamma();

        if (Config.fullbright) {
            if (saved == null) saved = gamma.getValue();
            if (gamma.getValue() < BRIGHT - 0.5) set(gamma, BRIGHT);
        } else if (saved != null) {
            set(gamma, saved);
            saved = null;
        }
    }

    /** Called on game shutdown so options.txt never stores the 16.0 value. */
    public static void restore(MinecraftClient mc) {
        if (saved != null && mc.options != null) {
            set(mc.options.getGamma(), saved);
            saved = null;
        }
    }
}
