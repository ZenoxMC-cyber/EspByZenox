package uz.espmod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP: draws boxes through walls for players, chests, ender chests and torches.
 * Block based targets are scanned every few ticks, players are read every frame.
 */
public final class Esp {
    private Esp() {}

    private record Target(Box box, int r, int g, int b) {}

    private static final int MAX_BLOCK_TARGETS = 3000;
    private static final int TORCH_CHUNK_RADIUS = 6;
    private static final int SCAN_INTERVAL_TICKS = 10;

    private static volatile List<Target> blockTargets = List.of();
    private static int tickCounter = 0;

    // ------------------------------------------------------------------ scanning

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null
                || !(Config.chestEsp || Config.enderChestEsp || Config.torchEsp)) {
            blockTargets = List.of();
            tickCounter = 0;
            return;
        }
        if (tickCounter++ % SCAN_INTERVAL_TICKS != 0) return;
        scan(mc);
    }

    private static void scan(MinecraftClient mc) {
        ClientWorld world = mc.world;
        int viewDistance = mc.options.getViewDistance().getValue();
        int radius = Math.min(viewDistance, 12);
        ChunkPos center = mc.player.getChunkPos();

        List<Target> out = new ArrayList<>();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                WorldChunk chunk = world.getChunkManager().getWorldChunk(center.x + dx, center.z + dz);
                if (chunk == null) continue;

                if (Config.chestEsp || Config.enderChestEsp) {
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (out.size() >= MAX_BLOCK_TARGETS) break;
                        if (be instanceof EnderChestBlockEntity) {
                            if (Config.enderChestEsp) out.add(blockTarget(world, be.getPos(), be.getCachedState(), 170, 60, 255));
                        } else if (be instanceof ChestBlockEntity) {
                            if (Config.chestEsp) out.add(blockTarget(world, be.getPos(), be.getCachedState(), 255, 170, 0));
                        }
                    }
                }

                if (Config.torchEsp && Math.abs(dx) <= TORCH_CHUNK_RADIUS && Math.abs(dz) <= TORCH_CHUNK_RADIUS) {
                    scanTorches(world, chunk, out);
                }
            }
        }
        blockTargets = out;
    }

    private static void scanTorches(ClientWorld world, WorldChunk chunk, List<Target> out) {
        ChunkSection[] sections = chunk.getSectionArray();
        int bottomSection = chunk.getBottomSectionCoord();
        ChunkPos cp = chunk.getPos();

        for (int i = 0; i < sections.length; i++) {
            ChunkSection section = sections[i];
            if (section == null || section.isEmpty() || !section.hasAny(Esp::isTorch)) continue;

            int baseY = (bottomSection + i) << 4;
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        if (out.size() >= MAX_BLOCK_TARGETS) return;
                        BlockState state = section.getBlockState(x, y, z);
                        if (!isTorch(state)) continue;
                        BlockPos pos = new BlockPos(cp.getStartX() + x, baseY + y, cp.getStartZ() + z);
                        out.add(blockTarget(world, pos, state, 255, 235, 60));
                    }
                }
            }
        }
    }

    private static boolean isTorch(BlockState s) {
        return s.isOf(Blocks.TORCH) || s.isOf(Blocks.WALL_TORCH)
                || s.isOf(Blocks.SOUL_TORCH) || s.isOf(Blocks.SOUL_WALL_TORCH)
                || s.isOf(Blocks.REDSTONE_TORCH) || s.isOf(Blocks.REDSTONE_WALL_TORCH);
    }

    private static Target blockTarget(ClientWorld world, BlockPos pos, BlockState state, int r, int g, int b) {
        VoxelShape shape = state.getOutlineShape(world, pos);
        Box box = shape.isEmpty() ? new Box(pos) : shape.getBoundingBox().offset(pos);
        return new Target(box, r, g, b);
    }

    // ----------------------------------------------------------------- rendering

    public static void render(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        if (!(Config.playerEsp || Config.chestEsp || Config.enderChestEsp || Config.torchEsp)) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;

        float tickDelta = context.tickCounter().getTickDelta(false);
        Vec3d cam = context.camera().getPos();

        List<Target> targets = new ArrayList<>(blockTargets);

        if (Config.playerEsp) {
            for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player) continue;
                Vec3d offset = p.getLerpedPos(tickDelta).subtract(p.getPos());
                targets.add(new Target(p.getBoundingBox().offset(offset), 255, 50, 50));
            }
        }
        if (targets.isEmpty()) return;

        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = matrices.peek().getPositionMatrix();

        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        // translucent fill
        BufferBuilder fill = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (Target t : targets) fillBox(fill, m, t.box(), t.r(), t.g(), t.b(), 45);
        draw(fill);

        // solid outline
        RenderSystem.lineWidth(2.0f);
        BufferBuilder lines = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (Target t : targets) outlineBox(lines, m, t.box(), t.r(), t.g(), t.b(), 255);
        draw(lines);

        RenderSystem.lineWidth(1.0f);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        matrices.pop();
    }

    private static void draw(BufferBuilder builder) {
        BuiltBuffer built = builder.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
    }

    private static void v(BufferBuilder b, Matrix4f m, double x, double y, double z, int r, int g, int bl, int a) {
        b.vertex(m, (float) x, (float) y, (float) z).color(r, g, bl, a);
    }

    private static void quad(BufferBuilder b, Matrix4f m, int r, int g, int bl, int a,
                             double x1, double y1, double z1, double x2, double y2, double z2,
                             double x3, double y3, double z3, double x4, double y4, double z4) {
        v(b, m, x1, y1, z1, r, g, bl, a);
        v(b, m, x2, y2, z2, r, g, bl, a);
        v(b, m, x3, y3, z3, r, g, bl, a);
        v(b, m, x4, y4, z4, r, g, bl, a);
    }

    private static void fillBox(BufferBuilder b, Matrix4f m, Box bx, int r, int g, int bl, int a) {
        double x1 = bx.minX, y1 = bx.minY, z1 = bx.minZ, x2 = bx.maxX, y2 = bx.maxY, z2 = bx.maxZ;
        quad(b, m, r, g, bl, a, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2); // bottom
        quad(b, m, r, g, bl, a, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1); // top
        quad(b, m, r, g, bl, a, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1); // north
        quad(b, m, r, g, bl, a, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2); // south
        quad(b, m, r, g, bl, a, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1); // west
        quad(b, m, r, g, bl, a, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2); // east
    }

    private static void line(BufferBuilder b, Matrix4f m, int r, int g, int bl, int a,
                             double x1, double y1, double z1, double x2, double y2, double z2) {
        v(b, m, x1, y1, z1, r, g, bl, a);
        v(b, m, x2, y2, z2, r, g, bl, a);
    }

    private static void outlineBox(BufferBuilder b, Matrix4f m, Box bx, int r, int g, int bl, int a) {
        double x1 = bx.minX, y1 = bx.minY, z1 = bx.minZ, x2 = bx.maxX, y2 = bx.maxY, z2 = bx.maxZ;
        // bottom
        line(b, m, r, g, bl, a, x1, y1, z1, x2, y1, z1);
        line(b, m, r, g, bl, a, x2, y1, z1, x2, y1, z2);
        line(b, m, r, g, bl, a, x2, y1, z2, x1, y1, z2);
        line(b, m, r, g, bl, a, x1, y1, z2, x1, y1, z1);
        // top
        line(b, m, r, g, bl, a, x1, y2, z1, x2, y2, z1);
        line(b, m, r, g, bl, a, x2, y2, z1, x2, y2, z2);
        line(b, m, r, g, bl, a, x2, y2, z2, x1, y2, z2);
        line(b, m, r, g, bl, a, x1, y2, z2, x1, y2, z1);
        // verticals
        line(b, m, r, g, bl, a, x1, y1, z1, x1, y2, z1);
        line(b, m, r, g, bl, a, x2, y1, z1, x2, y2, z1);
        line(b, m, r, g, bl, a, x2, y1, z2, x2, y2, z2);
        line(b, m, r, g, bl, a, x1, y1, z2, x1, y2, z2);
    }
}
