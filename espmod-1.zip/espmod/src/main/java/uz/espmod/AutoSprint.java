package uz.espmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;

/**
 * Auto sprint: holds the sprint key while you walk forward.
 * Vanilla still decides if sprinting is allowed (hunger, sneaking, using items...).
 */
public final class AutoSprint {
    private AutoSprint() {}

    private static boolean wasActive = false;

    public static void tick(MinecraftClient mc) {
        GameOptions o = mc.options;
        if (o == null) return;

        if (!Config.autoSprint || mc.player == null || Freecam.enabled) {
            if (wasActive) {
                o.sprintKey.setPressed(false);
                wasActive = false;
            }
            return;
        }

        boolean walkingForward = o.forwardKey.isPressed() && !o.sneakKey.isPressed();
        o.sprintKey.setPressed(walkingForward);
        wasActive = true;
    }
}
